#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Recover plan-gated organization Spaces through one proven personal runtime.

The recovery resolves the exact tested ``vertical-services/main`` revision before
any provider mutation. It actively validates every configured credential instead
of accepting the first present secret, proves a personal Docker runtime, and only
then converts the organization entry Spaces to free static gateways. All reports
are secret-free and all provider failures remain explicit.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import importlib.util
import json
import os
import re
import time
import urllib.error
import urllib.request
from contextlib import contextmanager
from dataclasses import dataclass, field
from pathlib import Path
from types import ModuleType
from typing import Any, Callable, Iterator, Mapping, Sequence

ROOT = Path(__file__).resolve().parents[1]
INTELLIGENCE_PUBLISHER = (
    ROOT / "scripts" / "hf_publish_vertical_services_intelligence_v4.py"
)
SOURCE_RESOLVER = ROOT / "scripts" / "hf_publish_vertical_flagships_v4.py"
RUNTIME_VERSION = "2.2.0"
RUNTIME_SLUG = "szl-vertical-services-runtime"
ORG = "SZLHOLDINGS"
ORG_WRITE_PROBE = f"{ORG}/vertical-services"
RECEIPT_PATH = Path("hf-free-tier-recovery-receipt.json")
RUNTIME_RECEIPT_PATH = Path("hf-personal-vertical-runtime-receipt.json")
USER_AGENT = "SZL-HF-Free-Tier-Recovery/2.0"
PROVIDER_CONSTRAINT = "HF_ORG_DYNAMIC_REQUIRES_TEAM_OR_ENTERPRISE"
SHA40 = re.compile(r"^[0-9a-f]{40}$")
TOKEN_SHAPE = re.compile(r"^hf_[A-Za-z0-9._-]{8,}$")

ORG_TOKEN_NAMES = (
    "HF_ORG_TOKEN",
    "HF_ORG_TOKEN1",
    "HF_WRITE_TOKEN",
    "HF_TOKEN",
    "HUGGINGFACE_TOKEN",
    "HUGGING_FACE_HUB_TOKEN",
    "HF_PERSONAL_TOKEN",
)
PERSONAL_TOKEN_NAMES = (
    "HF_PERSONAL_TOKEN",
    "HF_ORG_TOKEN1",
    "HF_ORG_TOKEN",
    "HF_WRITE_TOKEN",
    "HF_TOKEN",
    "HUGGINGFACE_TOKEN",
    "HUGGING_FACE_HUB_TOKEN",
)
TOKEN_ENV_NAMES = tuple(dict.fromkeys((*ORG_TOKEN_NAMES, *PERSONAL_TOKEN_NAMES)))

STATIC_SPACES = {
    "vertical-services": (
        "SZL Vertical Services",
        "Six governed engines, one operational fabric",
        "/",
    ),
    "terra": (
        "Terra",
        "Parcel-to-portfolio real-estate intelligence",
        "/experience/terra",
    ),
    "counsel": (
        "PRISM Counsel",
        "Evidence-linked legal matter intelligence",
        "/experience/prism",
    ),
    "finance": (
        "PURIQ Finance",
        "Provenance-first financial intelligence",
        "/experience/puriq",
    ),
    "lyte": (
        "Lyte",
        "Business and agent observability command",
        "/experience/lyte",
    ),
}
DELETE_DYNAMIC_FILES = (
    "Dockerfile",
    "Dockerfile.dockerignore",
    "app.py",
    "requirements.txt",
    "config.json",
)


class RecoveryError(RuntimeError):
    """Base class for a fail-closed recovery refusal."""


class CredentialSelectionError(RecoveryError):
    """No configured token passed the required active validation."""

    def __init__(self, message: str, *, attempts: Sequence[dict[str, Any]]) -> None:
        super().__init__(message)
        self.attempts = tuple(dict(item) for item in attempts)


class ProviderPlanRequired(CredentialSelectionError):
    """A valid personal identity was blocked by the dynamic-Space plan gate."""


class RuntimeProofError(RecoveryError):
    """The personal runtime did not pass exact-source public verification."""


@dataclass(frozen=True)
class Credential:
    source: str
    owner: str
    token: str = field(repr=False, compare=False)
    target_repo: str | None = None


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat().replace("+00:00", "Z")


def load_module(path: Path, name: str) -> ModuleType:
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RecoveryError(f"cannot load required module: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def http_status(error: BaseException) -> int | None:
    response = getattr(error, "response", None)
    for value in (
        getattr(response, "status_code", None),
        getattr(error, "status_code", None),
        getattr(error, "code", None),
    ):
        if isinstance(value, int):
            return value
    return None


def failure_evidence(
    source: str,
    error: BaseException,
    *,
    purpose: str,
) -> dict[str, Any]:
    text = str(error)
    return {
        "source": source,
        "purpose": purpose,
        "present": True,
        "valid": False,
        "failure_type": type(error).__name__,
        "status_code": http_status(error),
        "failure_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
        "token_value_recorded": False,
    }


def normalize_token(value: str) -> str:
    token = str(value or "").strip()
    if not TOKEN_SHAPE.fullmatch(token):
        raise CredentialSelectionError(
            "credential does not match a Hugging Face token shape",
            attempts=(),
        )
    return token


def candidate_tokens(
    names: Sequence[str],
    environment: Mapping[str, str],
) -> Iterator[tuple[str, str | None]]:
    seen: set[str] = set()
    for name in names:
        raw = str(environment.get(name) or "").strip()
        if not raw:
            yield name, None
            continue
        if raw in seen:
            continue
        seen.add(raw)
        yield name, raw


def identity_owner(identity: Any, *, reject_org: bool = True) -> str:
    if not isinstance(identity, Mapping):
        raise RecoveryError("Hugging Face identity response was not an object")
    owner = str(identity.get("name") or "").strip()
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,95}", owner):
        raise RecoveryError("Hugging Face token owner is unavailable or malformed")
    if reject_org and owner.casefold() == ORG.casefold():
        raise RecoveryError("token resolved to the organization, not a personal owner")
    return owner


def space_origin(repo_id: str) -> str:
    owner, slug = repo_id.split("/", 1)
    host = f"{owner}-{slug}".lower().replace("_", "-").replace(".", "-")
    return f"https://{host}.hf.space"


def select_org_credential(
    *,
    environment: Mapping[str, str],
    api_factory: Callable[..., Any],
) -> tuple[Credential, list[dict[str, Any]]]:
    attempts: list[dict[str, Any]] = []
    for source, raw in candidate_tokens(ORG_TOKEN_NAMES, environment):
        if raw is None:
            attempts.append(
                {
                    "source": source,
                    "purpose": "organization_gateway",
                    "present": False,
                    "valid": False,
                    "token_value_recorded": False,
                }
            )
            continue
        try:
            token = normalize_token(raw)
            api = api_factory(token=token)
            owner = identity_owner(api.whoami())
            api.auth_check(
                repo_id=ORG_WRITE_PROBE,
                repo_type="space",
                write=True,
            )
            attempts.append(
                {
                    "source": source,
                    "purpose": "organization_gateway",
                    "present": True,
                    "valid": True,
                    "target_access": "EXISTING_ORG_WRITE_CONFIRMED",
                    "token_value_recorded": False,
                }
            )
            return Credential(source=source, owner=owner, token=token), attempts
        except Exception as error:  # each candidate remains independently eligible
            attempts.append(
                failure_evidence(source, error, purpose="organization_gateway")
            )
    raise CredentialSelectionError(
        "no configured credential has write access to the organization gateway probe",
        attempts=attempts,
    )


def select_personal_credential(
    *,
    environment: Mapping[str, str],
    api_factory: Callable[..., Any],
) -> tuple[Credential, list[dict[str, Any]]]:
    attempts: list[dict[str, Any]] = []
    plan_blocked = False
    for source, raw in candidate_tokens(PERSONAL_TOKEN_NAMES, environment):
        if raw is None:
            attempts.append(
                {
                    "source": source,
                    "purpose": "personal_dynamic_runtime",
                    "present": False,
                    "valid": False,
                    "token_value_recorded": False,
                }
            )
            continue
        try:
            token = normalize_token(raw)
            api = api_factory(token=token)
            owner = identity_owner(api.whoami())
            repo_id = f"{owner}/{RUNTIME_SLUG}"
            # This is the only pre-proof provider mutation. It is confined to the
            # authenticated personal namespace and simultaneously proves create
            # permission plus the current dynamic-Space subscription entitlement.
            api.create_repo(
                repo_id=repo_id,
                repo_type="space",
                space_sdk="docker",
                exist_ok=True,
                private=False,
            )
            api.auth_check(repo_id=repo_id, repo_type="space", write=True)
            attempts.append(
                {
                    "source": source,
                    "purpose": "personal_dynamic_runtime",
                    "present": True,
                    "valid": True,
                    "target_access": "PERSONAL_DOCKER_WRITE_CONFIRMED",
                    "target_repo": repo_id,
                    "token_value_recorded": False,
                }
            )
            return (
                Credential(
                    source=source,
                    owner=owner,
                    token=token,
                    target_repo=repo_id,
                ),
                attempts,
            )
        except Exception as error:  # try later credentials after stale/invalid ones
            status = http_status(error)
            evidence = failure_evidence(
                source,
                error,
                purpose="personal_dynamic_runtime",
            )
            if status == 402:
                evidence["provider_plan_required"] = True
                plan_blocked = True
            attempts.append(evidence)
    error_type: type[CredentialSelectionError]
    message: str
    if plan_blocked:
        error_type = ProviderPlanRequired
        message = (
            "no configured personal identity can create or retain a dynamic Space; "
            "Hugging Face PRO is required for the personal Docker runtime"
        )
    else:
        error_type = CredentialSelectionError
        message = "no configured credential can publish the personal Docker runtime"
    raise error_type(message, attempts=attempts)


def require_upstream_plan_gate(
    path: Path,
    *,
    expected_run_id: int,
    expected_head_sha: str,
) -> dict[str, Any]:
    """Admit recovery only from the exact failed canonical publication receipt."""

    try:
        raw = path.read_bytes()
        receipt = json.loads(raw)
    except (OSError, json.JSONDecodeError) as error:
        raise RecoveryError("canonical publisher receipt is absent or invalid") from error
    if not isinstance(receipt, dict):
        raise RecoveryError("canonical publisher receipt was not an object")
    if SHA40.fullmatch(expected_head_sha) is None:
        raise RecoveryError("upstream workflow head is not a full Git SHA")
    if receipt.get("workflow_run_id") != expected_run_id:
        raise RecoveryError("canonical publisher receipt names the wrong workflow run")
    if receipt.get("source_revision") != expected_head_sha:
        raise RecoveryError("canonical publisher receipt names the wrong Git head")
    if receipt.get("complete") is not False:
        raise RecoveryError("canonical publisher did not emit a failed recovery trigger")

    encoded = json.dumps(receipt, sort_keys=True).casefold()
    plan_evidence = (
        "402 payment required" in encoded
        and "team or enterprise plan" in encoded
        and "static spaces are free" in encoded
    )
    if not plan_evidence:
        raise RecoveryError(
            "canonical publisher failure is not the exact organization plan gate"
        )
    if '"token_value_recorded": true' in encoded:
        raise RecoveryError("upstream receipt unexpectedly records credential material")
    return {
        "schema": "szl.hf-plan-gate-admission/v1",
        "workflow_run_id": expected_run_id,
        "head_sha": expected_head_sha,
        "receipt_sha256": hashlib.sha256(raw).hexdigest(),
        "http_status": 402,
        "constraint": PROVIDER_CONSTRAINT,
        "recovery_admitted": True,
        "token_value_recorded": False,
        "truth_label": "MEASURED",
    }


def resolve_runtime_source() -> tuple[str, dict[str, Any]]:
    resolver = load_module(SOURCE_RESOLVER, "szl_tested_vertical_source_resolver")
    revision, evidence = resolver.resolve_tested_vertical_services_tip()
    revision = str(revision).lower()
    if SHA40.fullmatch(revision) is None:
        raise RecoveryError("tested vertical source did not resolve to a full Git SHA")
    if not isinstance(evidence, dict):
        raise RecoveryError("tested vertical source evidence was not an object")
    if (
        evidence.get("revision") != revision
        or evidence.get("python_contract_suite") != "success"
        or evidence.get("default_branch_tip_rechecked_by_deployer") is not True
    ):
        raise RecoveryError("tested vertical source evidence is incomplete or drifted")
    return revision, dict(evidence)


@contextmanager
def isolated_hf_token(token: str) -> Iterator[None]:
    saved = {name: os.environ.get(name) for name in TOKEN_ENV_NAMES}
    saved_disable = os.environ.get("HF_HUB_DISABLE_IMPLICIT_TOKEN")
    try:
        for name in TOKEN_ENV_NAMES:
            os.environ.pop(name, None)
        os.environ["HF_TOKEN"] = token
        os.environ["HF_HUB_DISABLE_IMPLICIT_TOKEN"] = "1"
        yield
    finally:
        for name in TOKEN_ENV_NAMES:
            os.environ.pop(name, None)
        for name, value in saved.items():
            if value is not None:
                os.environ[name] = value
        if saved_disable is None:
            os.environ.pop("HF_HUB_DISABLE_IMPLICIT_TOKEN", None)
        else:
            os.environ["HF_HUB_DISABLE_IMPLICIT_TOKEN"] = saved_disable


def deploy_personal_runtime(
    token: str,
    owner: str,
    source_revision: str,
) -> dict[str, Any]:
    if SHA40.fullmatch(source_revision) is None:
        raise RuntimeProofError("personal runtime source is not a full Git SHA")

    wrapper = load_module(INTELLIGENCE_PUBLISHER, "szl_hf_intelligence_v4_recovery")
    wrapper.SOURCE_REVISION = source_revision
    v3 = wrapper.configure_v4(wrapper.load_v3())
    base = v3.configure(v3.load_base())

    repo_id = f"{owner}/{RUNTIME_SLUG}"
    origin = space_origin(repo_id)
    base.HF_REPOSITORY = repo_id
    base.ORIGIN = origin
    base.RECEIPT_PATH = RUNTIME_RECEIPT_PATH
    base.USER_AGENT = USER_AGENT

    with isolated_hf_token(token):
        exit_code = int(base.main())

    try:
        receipt = json.loads(RUNTIME_RECEIPT_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise RuntimeProofError("personal runtime did not emit a valid receipt") from error
    if not isinstance(receipt, dict):
        raise RuntimeProofError("personal runtime receipt was not an object")

    error_text = str(receipt.get("error") or "")
    if "402" in error_text or "payment required" in error_text.casefold():
        raise ProviderPlanRequired(
            "personal Docker runtime is blocked by the Hugging Face PRO plan gate",
            attempts=(),
        )
    if exit_code != 0 or receipt.get("complete") is not True:
        raise RuntimeProofError("personal vertical runtime did not pass live proof")
    if receipt.get("source_revision") != source_revision:
        raise RuntimeProofError("personal runtime receipt names the wrong source revision")
    if receipt.get("hf_repository") != repo_id or receipt.get("origin") != origin:
        raise RuntimeProofError("personal runtime receipt names the wrong provider target")

    return {
        "repo_id": repo_id,
        "origin": origin,
        "source_revision": source_revision,
        "version": RUNTIME_VERSION,
        "receipt_sha256": hashlib.sha256(
            json.dumps(receipt, sort_keys=True, separators=(",", ":")).encode()
        ).hexdigest(),
        "complete": True,
    }


def static_card(title: str, description: str) -> str:
    return (
        "---\n"
        f"title: {title}\n"
        "emoji: 🧬\ncolorFrom: gray\ncolorTo: indigo\n"
        "sdk: static\napp_file: index.html\npinned: false\nlicense: apache-2.0\n"
        f"short_description: {description[:60]}\n"
        "---\n\n"
        f"#"---\n"
  \n"
        "Static public entry surface backed by an exact-source SZL governed runtime.\n"
        "The runtime remains proposal-only, deny-by-default, human-authorized, and receipted.\n"
    )


def static_page(
    title: str,
    description: str,
    target: str,
    build: Mapping[str, Any],
) -> str:
    target_json = json.dumps(target)
    build_json = json.dumps(dict(build), sort_keys=True, separators=(",", ":"))
    return f'''<!doctype html>
<html lang="en" data-szl-domain-experience-v4="true">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>---\n"
 · SZL Holdings</title><style>
:root{{color-scheme:dark;font-family:Inter,ui-sans-serif,system-ui;background:#07090d;color:#f4f7fb}}
*{{box-sizing:border-box}}body{{min-height:100vh;margin:0;display:grid;place-items:center;padding:24px;background:radial-gradient(circle at 20% 10%,#19203a 0,transparent 38%),#07090d}}
main{{width:min(760px,100%);padding:clamp(28px,6vw,72px);border:1px solid #30384d;border-radius:24px;background:#0c1019e8;box-shadow:0 24px 90px #0009}}
.kicker{{font:700 12px/1.2 ui-monospace,monospace;letter-spacing:.16em;color:#9eb4ff}}h1{{font-size:clamp(40px,9vw,84px);line-height:.92;margin:18px 0}}p{{font-size:clamp(16px,2.5vw,20px);line-height:1.6;color:#c3cbe0}}
a{{display:inline-grid;place-items:center;min-height:48px;min-width:48px;margin-top:20px;padding:0 22px;border-radius:999px;background:#f4f7fb;color:#080a10;text-decoration:none;font-weight:800}}
small{{display:block;margin-top:24px;color:#7f8ba8;overflow-wrap:anywhere}}@media(prefers-reduced-motion:reduce){{*{{scroll-behavior:auto!important}}}}@media(forced-colors:active){{main,a{{border:1px solid CanvasText}}}}
</style></head><body><main><div class="kicker">SZL HOLDINGS · SOURCE-BOUND ENTRY</div><h1>---\n"
</h1><p>{description}. Opening the live governed engine.</p><a id="open" href="{target}">Open live engine</a><small>Source {build['runtime_source_revision'][:12]
 · Runtime {build['runtime_version']
 · Human authority required</small></main>
<script>const target={target_json};setTimeout(()=>location.replace(target+location.search+location.hash),900);</script>
<script type="application/json" id="szl-build-info">{build_json}</script></body></html>'''


def anonymous_html(
    url: str,
    *,
    expected_fragments: Sequence[str] = (),
    attempts: int = 30,
) -> tuple[int, str]:
    last_status = 0
    last_text = ""
    for attempt in range(attempts):
        request = urllib.request.Request(
            f"{url}?szl_static_verify={time.time_ns()}",
            headers={"Cache-Control": "no-cache", "User-Agent": USER_AGENT},
        )
        try:
            with urllib.request.urlopen(request, timeout=30) as response:
                last_status = response.status
                last_text = response.read(1_000_000).decode("utf-8", "replace")
                if response.status == 200 and all(
                    fragment in last_text for fragment in expected_fragments
                ):
                    return response.status, last_text
        except urllib.error.HTTPError as error:
            last_status = error.code
            last_text = error.read(1_000_000).decode("utf-8", "replace")
        except urllib.error.URLError:
            last_status = 0
            last_text = ""
        if attempt + 1 < attempts:
            time.sleep(min(20, 2 + attempt))
    return last_status, last_text


def publish_static_gateway(
    api: Any,
    slug: str,
    meta: tuple[str, str, str],
    runtime: Mapping[str, Any],
) -> dict[str, Any]:
    from huggingface_hub import CommitOperationAdd, CommitOperationDelete

    title, description, path = meta
    repo_id = f"{ORG}/{slug}"
    # ``exist_ok`` handles both existing and absent repositories. No broad catch
    # converts authentication, rate-limit, or provider errors into "repo missing".
    api.create_repo(
        repo_id=repo_id,
        repo_type="space",
        space_sdk="static",
        exist_ok=True,
        private=False,
    )
    api.auth_check(repo_id=repo_id, repo_type="space", write=True)
    files = set(api.list_repo_files(repo_id=repo_id, repo_type="space"))

    target = str(runtime["origin"]).rstrip("/") + path
    build = {
        "schema": "szl.static-runtime-gateway/v1",
        "generated_at": utc_now(),
        "hf_repository": repo_id,
        "deployment_mode": "STATIC_ORG_GATEWAY_PERSONAL_DYNAMIC_RUNTIME",
        "gateway_source_revision": (
            os.getenv("HF_UPSTREAM_HEAD_SHA")
            or os.getenv("GITHUB_SHA")
            or "UNAVAILABLE"
        ),
        "runtime_repository": runtime["repo_id"],
        "runtime_source_revision": runtime["source_revision"],
        "runtime_version": runtime["version"],
        "runtime_target": target,
        "provider_constraint": PROVIDER_CONSTRAINT,
        "effectors_enabled": False,
        "human_approval_required": True,
    }
    payloads = {
        "README.md": static_card(title, description).encode(),
        "index.html": static_page(title, description, target, build).encode(),
        "build-info.json": (json.dumps(build, indent=2) + "\n").encode(),
        ".well-known/szl-source.json": (json.dumps(build, indent=2) + "\n").encode(),
    }
    operations: list[Any] = [
        CommitOperationAdd(path_in_repo=name, path_or_fileobj=data)
        for name, data in payloads.items()
    ]
    operations.extend(
        CommitOperationDelete(path_in_repo=name)
        for name in DELETE_DYNAMIC_FILES
        if name in files
    )
    commit = api.create_commit(
        repo_id=repo_id,
        repo_type="space",
        operations=operations,
        commit_message=f"ops: convert {slug} to source-bound static gateway",
    )

    origin = space_origin(repo_id)
    required = (
        'data-szl-domain-experience-v4="true"',
        str(runtime["source_revision"]),
        target,
        PROVIDER_CONSTRAINT,
    )
    status, live = anonymous_html(origin, expected_fragments=required)
    missing = [fragment for fragment in required if fragment not in live]
    return {
        "repo_id": repo_id,
        "origin": origin,
        "target": target,
        "commit": str(
            getattr(commit, "oid", "") or getattr(commit, "commit_url", "")
        ),
        "http_status": status,
        "missing_live_fragments": missing,
        "operational": status == 200 and not missing,
        "deleted_dynamic_files": sorted(
            name for name in DELETE_DYNAMIC_FILES if name in files
        ),
    }


def run_recovery(
    report: dict[str, Any],
    *,
    environment: Mapping[str, str],
    api_factory: Callable[..., Any],
    upstream_gate: Callable[[], dict[str, Any]],
    source_resolver: Callable[[], tuple[str, dict[str, Any]]] = resolve_runtime_source,
    runtime_deployer: Callable[[str, str, str], dict[str, Any]] = deploy_personal_runtime,
    gateway_publisher: Callable[
        [Any, str, tuple[str, str, str], Mapping[str, Any]],
        dict[str, Any],
    ] = publish_static_gateway,
) -> None:
    report["upstream_plan_gate"] = upstream_gate()
    source_revision, source_evidence = source_resolver()
    report["source_resolution"] = source_evidence
    report["runtime_source_revision"] = source_revision

    org_credential, org_attempts = select_org_credential(
        environment=environment,
        api_factory=api_factory,
    )
    report["organization_credential_attempts"] = org_attempts
    report["organization_credential_source"] = org_credential.source

    personal_credential, personal_attempts = select_personal_credential(
        environment=environment,
        api_factory=api_factory,
    )
    report["personal_credential_attempts"] = personal_attempts
    report["personal_credential_source"] = personal_credential.source
    report["personal_owner"] = personal_credential.owner
    report["personal_runtime_repository"] = personal_credential.target_repo
    report["personal_runtime_preflight_complete"] = True

    runtime = runtime_deployer(
        personal_credential.token,
        personal_credential.owner,
        source_revision,
    )
    if runtime.get("complete") is not True:
        raise RuntimeProofError("personal runtime proof did not close")
    report["personal_runtime_proved"] = True
    report["runtime"] = {
        key: runtime[key]
        for key in (
            "repo_id",
            "origin",
            "source_revision",
            "version",
            "receipt_sha256",
        )
    }

    # Organization mutation starts only after the exact-source personal runtime
    # is publicly proven. A failed runtime can therefore never delete a launcher.
    report["organization_gateway_mutation_started"] = True
    org_api = api_factory(token=org_credential.token)
    rows: list[dict[str, Any]] = []
    for slug, meta in STATIC_SPACES.items():
        rows.append(gateway_publisher(org_api, slug, meta, runtime))
    report["gateways"] = rows
    report["gateways_operational"] = sum(
        1 for row in rows if row.get("operational") is True
    )
    report["gateways_total"] = len(rows)
    report["complete"] = report["gateways_operational"] == len(rows)


def redact_error(error: BaseException, environment: Mapping[str, str]) -> str:
    message = str(error)
    for name in TOKEN_ENV_NAMES:
        token = str(environment.get(name) or "").strip()
        if token:
            message = message.replace(token, "[REDACTED]")
    return message[:1000]


def main() -> int:
    report: dict[str, Any] = {
        "schema": "szl.hf-free-tier-recovery/v2",
        "started_at": utc_now(),
        "provider_constraint": PROVIDER_CONSTRAINT,
        "token_value_recorded": False,
        "token_hash_recorded": False,
        "personal_runtime_preflight_complete": False,
        "personal_runtime_proved": False,
        "organization_gateway_mutation_started": False,
        "complete": False,
    }
    exit_code = 1
    environment = dict(os.environ)
    try:
        from huggingface_hub import HfApi

        upstream_path = Path(
            environment.get("HF_UPSTREAM_RECEIPT", "").strip()
        )
        upstream_run = int(environment.get("HF_UPSTREAM_RUN_ID", "0"))
        upstream_head = environment.get("HF_UPSTREAM_HEAD_SHA", "").strip().lower()
        run_recovery(
            report,
            environment=environment,
            api_factory=HfApi,
            upstream_gate=lambda: require_upstream_plan_gate(
                upstream_path,
                expected_run_id=upstream_run,
                expected_head_sha=upstream_head,
            ),
        )
        exit_code = 0 if report["complete"] else 1
    except CredentialSelectionError as error:
        if isinstance(error, ProviderPlanRequired):
            report["state"] = "PROVIDER_PLAN_REQUIRED"
        else:
            report["state"] = "AUTH_REQUIRED"
        purpose = (
            "personal_credential_attempts"
            if any(
                item.get("purpose") == "personal_dynamic_runtime"
                for item in error.attempts
            )
            else "organization_credential_attempts"
        )
        if purpose not in report:
            report[purpose] = list(error.attempts)
        report["error"] = {
            "type": type(error).__name__,
            "message": redact_error(error, environment),
            "status_code": 402 if isinstance(error, ProviderPlanRequired) else None,
        }
    except Exception as error:
        report["state"] = "FAILED"
        report["error"] = {
            "type": type(error).__name__,
            "message": redact_error(error, environment),
            "status_code": http_status(error),
            "failure_sha256": hashlib.sha256(
                str(error).encode("utf-8")
            ).hexdigest(),
        }

    report["finished_at"] = utc_now()
    canonical = json.dumps(report, sort_keys=True, separators=(",", ":")).encode()
    report["receipt_sha256"] = hashlib.sha256(canonical).hexdigest()
    RECEIPT_PATH.write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(report, indent=2, sort_keys=True))
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
