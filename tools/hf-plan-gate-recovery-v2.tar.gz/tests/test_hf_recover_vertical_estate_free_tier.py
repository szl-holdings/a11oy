# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import importlib.util
import json
import os
import sys
import types
from pathlib import Path
from types import SimpleNamespace

import pytest

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "hf_recover_vertical_estate_free_tier.py"
SPEC = importlib.util.spec_from_file_location("hf_free_tier_recovery", SCRIPT)
assert SPEC and SPEC.loader
module = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = module
SPEC.loader.exec_module(module)


class Response:
    def __init__(self, status_code: int) -> None:
        self.status_code = status_code


class HubError(RuntimeError):
    def __init__(self, message: str, status_code: int) -> None:
        super().__init__(message)
        self.response = Response(status_code)


class API:
    def __init__(self, token: str, behavior: dict[str, dict]) -> None:
        self.token = token
        self.behavior = behavior[token]
        self.calls: list[tuple[str, object]] = []

    def whoami(self):
        self.calls.append(("whoami", None))
        error = self.behavior.get("whoami_error")
        if error:
            raise error
        return {"name": self.behavior.get("owner", "stephen")}

    def auth_check(self, **kwargs):
        self.calls.append(("auth_check", kwargs.get("repo_id")))
        error = self.behavior.get("auth_error")
        if error:
            raise error
        return None

    def create_repo(self, **kwargs):
        self.calls.append(("create_repo", kwargs.get("repo_id")))
        error = self.behavior.get("create_error")
        if error:
            raise error
        return SimpleNamespace(repo_id=kwargs.get("repo_id"))


def factory_for(behavior: dict[str, dict]):
    instances: list[API] = []

    def factory(*, token: str):
        api = API(token, behavior)
        instances.append(api)
        return api

    factory.instances = instances
    return factory


def test_topology_is_static_gateway_only_and_source_is_resolved_at_runtime() -> None:
    assert set(module.STATIC_SPACES) == {
        "vertical-services",
        "terra",
        "counsel",
        "finance",
        "lyte",
    }
    assert module.STATIC_SPACES["finance"][2] == "/experience/puriq"
    assert module.STATIC_SPACES["counsel"][2] == "/experience/prism"
    text = SCRIPT.read_text(encoding="utf-8")
    assert "RUNTIME_SOURCE_REVISION" not in text
    assert "resolve_tested_vertical_services_tip" in text
    assert "HF_ORG_TOKEN1" in text


def test_identity_owner_and_space_origin_are_strict() -> None:
    assert module.identity_owner({"name": "stephen-lutar"}) == "stephen-lutar"
    assert (
        module.space_origin("Example_User/Runtime.One")
        == "https://example-user-runtime-one.hf.space"
    )
    for value in ({}, {"name": ""}, {"name": "SZLHOLDINGS"}, {"name": "bad/name"}):
        with pytest.raises(module.RecoveryError):
            module.identity_owner(value)


def test_org_selector_skips_stale_secret_and_accepts_later_valid_token() -> None:
    stale = "hf_stalecredential"
    valid = "hf_validcredential"
    behavior = {
        stale: {"whoami_error": HubError("unauthorized", 401)},
        valid: {"owner": "stephen"},
    }
    factory = factory_for(behavior)
    credential, attempts = module.select_org_credential(
        environment={"HF_ORG_TOKEN": stale, "HF_ORG_TOKEN1": valid},
        api_factory=factory,
    )
    assert credential.source == "HF_ORG_TOKEN1"
    assert credential.token == valid
    assert [row["valid"] for row in attempts if row["present"]] == [False, True]
    assert attempts[0]["status_code"] == 401
    assert all("token" not in row or row["token_value_recorded"] is False for row in attempts)


def test_personal_selector_skips_stale_secret_and_proves_dynamic_repo() -> None:
    stale = "hf_stalecredential"
    valid = "hf_validcredential"
    behavior = {
        stale: {"whoami_error": HubError("unauthorized", 401)},
        valid: {"owner": "stephen"},
    }
    factory = factory_for(behavior)
    credential, attempts = module.select_personal_credential(
        environment={"HF_PERSONAL_TOKEN": stale, "HF_ORG_TOKEN1": valid},
        api_factory=factory,
    )
    assert credential.source == "HF_ORG_TOKEN1"
    assert credential.target_repo == "stephen/szl-vertical-services-runtime"
    successful = factory.instances[-1]
    assert ("create_repo", credential.target_repo) in successful.calls
    assert ("auth_check", credential.target_repo) in successful.calls
    assert attempts[-1]["target_access"] == "PERSONAL_DOCKER_WRITE_CONFIRMED"


def test_personal_selector_surfaces_402_plan_gate_after_bounded_candidates() -> None:
    token = "hf_planblockedtoken"
    behavior = {
        token: {
            "owner": "stephen",
            "create_error": HubError("402 Payment Required", 402),
        }
    }
    with pytest.raises(module.ProviderPlanRequired) as captured:
        module.select_personal_credential(
            environment={"HF_PERSONAL_TOKEN": token},
            api_factory=factory_for(behavior),
        )
    attempts = captured.value.attempts
    assert attempts[0]["status_code"] == 402
    assert attempts[0]["provider_plan_required"] is True


def test_upstream_plan_gate_requires_exact_run_head_and_402_receipt(tmp_path) -> None:
    head = "a" * 40
    path = tmp_path / "upstream.json"
    path.write_text(
        json.dumps(
            {
                "complete": False,
                "workflow_run_id": 42,
                "source_revision": head,
                "token_value_recorded": False,
                "rows": [
                    {
                        "error": (
                            "402 Payment Required: Static Spaces are free for everyone, "
                            "but Docker Spaces require a Team or Enterprise plan"
                        )
                    }
                ],
            }
        ),
        encoding="utf-8",
    )
    evidence = module.require_upstream_plan_gate(
        path, expected_run_id=42, expected_head_sha=head
    )
    assert evidence["recovery_admitted"] is True
    assert evidence["http_status"] == 402


@pytest.mark.parametrize(
    "change",
    [
        {"workflow_run_id": 99},
        {"source_revision": "b" * 40},
        {"complete": True},
        {"rows": [{"error": "unrelated failure"}]},
    ],
)
def test_upstream_plan_gate_rejects_unrelated_or_stale_failure(tmp_path, change) -> None:
    head = "a" * 40
    receipt = {
        "complete": False,
        "workflow_run_id": 42,
        "source_revision": head,
        "token_value_recorded": False,
        "rows": [
            {
                "error": (
                    "402 Payment Required: Static Spaces are free for everyone, "
                    "but Docker Spaces require a Team or Enterprise plan"
                )
            }
        ],
    }
    receipt.update(change)
    path = tmp_path / "upstream.json"
    path.write_text(json.dumps(receipt), encoding="utf-8")
    with pytest.raises(module.RecoveryError):
        module.require_upstream_plan_gate(
            path, expected_run_id=42, expected_head_sha=head
        )


def test_source_resolver_requires_exact_successful_contract(monkeypatch) -> None:
    revision = "a" * 40
    resolver = SimpleNamespace(
        resolve_tested_vertical_services_tip=lambda: (
            revision,
            {
                "revision": revision,
                "python_contract_suite": "success",
                "default_branch_tip_rechecked_by_deployer": True,
            },
        )
    )
    monkeypatch.setattr(module, "load_module", lambda *_args: resolver)
    observed, evidence = module.resolve_runtime_source()
    assert observed == revision
    assert evidence["revision"] == revision


@pytest.mark.parametrize(
    "revision,evidence",
    [
        ("short", {}),
        (
            "a" * 40,
            {
                "revision": "b" * 40,
                "python_contract_suite": "success",
                "default_branch_tip_rechecked_by_deployer": True,
            },
        ),
        (
            "a" * 40,
            {
                "revision": "a" * 40,
                "python_contract_suite": "failure",
                "default_branch_tip_rechecked_by_deployer": True,
            },
        ),
    ],
)
def test_source_resolver_rejects_drift(monkeypatch, revision, evidence) -> None:
    resolver = SimpleNamespace(
        resolve_tested_vertical_services_tip=lambda: (revision, evidence)
    )
    monkeypatch.setattr(module, "load_module", lambda *_args: resolver)
    with pytest.raises(module.RecoveryError):
        module.resolve_runtime_source()


def test_isolated_token_environment_masks_stale_aliases_and_restores(monkeypatch) -> None:
    monkeypatch.setenv("HF_ORG_TOKEN", "hf_stalecredential")
    monkeypatch.setenv("HF_ORG_TOKEN1", "hf_othercredential")
    monkeypatch.delenv("HF_TOKEN", raising=False)
    with module.isolated_hf_token("hf_selectedcredential"):
        assert os.environ["HF_TOKEN"] == "hf_selectedcredential"
        assert "HF_ORG_TOKEN" not in os.environ
        assert "HF_ORG_TOKEN1" not in os.environ
        assert os.environ["HF_HUB_DISABLE_IMPLICIT_TOKEN"] == "1"
    assert os.environ["HF_ORG_TOKEN"] == "hf_stalecredential"
    assert os.environ["HF_ORG_TOKEN1"] == "hf_othercredential"
    assert "HF_TOKEN" not in os.environ


def test_personal_runtime_override_reaches_underlying_base(monkeypatch, tmp_path) -> None:
    revision = "c" * 40
    receipt_path = tmp_path / "runtime.json"
    monkeypatch.setattr(module, "RUNTIME_RECEIPT_PATH", receipt_path)
    observed: dict[str, object] = {}

    class Base:
        def main(self):
            observed.update(
                {
                    "repo": self.HF_REPOSITORY,
                    "origin": self.ORIGIN,
                    "source": self.SOURCE_REVISION,
                    "hf_token": os.environ.get("HF_TOKEN"),
                    "stale": os.environ.get("HF_ORG_TOKEN"),
                }
            )
            self.RECEIPT_PATH.write_text(
                json.dumps(
                    {
                        "complete": True,
                        "source_revision": self.SOURCE_REVISION,
                        "hf_repository": self.HF_REPOSITORY,
                        "origin": self.ORIGIN,
                    }
                ),
                encoding="utf-8",
            )
            return 0

    class V3:
        SOURCE_REVISION = "old"

        def load_base(self):
            return Base()

        def configure(self, base):
            base.SOURCE_REVISION = self.SOURCE_REVISION
            return base

    class Wrapper:
        SOURCE_REVISION = "old"

        def load_v3(self):
            return V3()

        def configure_v4(self, v3):
            v3.SOURCE_REVISION = self.SOURCE_REVISION
            return v3

    monkeypatch.setattr(module, "load_module", lambda *_args: Wrapper())
    monkeypatch.setenv("HF_ORG_TOKEN", "hf_stalecredential")
    result = module.deploy_personal_runtime(
        "hf_selectedcredential",
        "stephen",
        revision,
    )
    assert result["complete"] is True
    assert observed == {
        "repo": "stephen/szl-vertical-services-runtime",
        "origin": "https://stephen-szl-vertical-services-runtime.hf.space",
        "source": revision,
        "hf_token": "hf_selectedcredential",
        "stale": None,
    }


def test_gateway_provider_error_is_not_reclassified_as_missing(monkeypatch) -> None:
    hub = types.ModuleType("huggingface_hub")

    class Add:
        def __init__(self, **kwargs):
            self.kwargs = kwargs

    class Delete(Add):
        pass

    hub.CommitOperationAdd = Add
    hub.CommitOperationDelete = Delete
    monkeypatch.setitem(sys.modules, "huggingface_hub", hub)

    class GatewayAPI:
        def __init__(self):
            self.create_calls = 0

        def create_repo(self, **_kwargs):
            self.create_calls += 1

        def auth_check(self, **_kwargs):
            return None

        def list_repo_files(self, **_kwargs):
            raise HubError("provider unavailable", 503)

    api = GatewayAPI()
    with pytest.raises(HubError, match="provider unavailable"):
        module.publish_static_gateway(
            api,
            "terra",
            module.STATIC_SPACES["terra"],
            {
                "repo_id": "stephen/runtime",
                "origin": "https://stephen-runtime.hf.space",
                "source_revision": "d" * 40,
                "version": "2.2.0",
            },
        )
    assert api.create_calls == 1


def test_runtime_failure_prevents_every_org_gateway_mutation(monkeypatch) -> None:
    credential = module.Credential(
        source="HF_ORG_TOKEN1",
        owner="stephen",
        token="hf_selectedcredential",
        target_repo="stephen/szl-vertical-services-runtime",
    )
    monkeypatch.setattr(
        module,
        "select_org_credential",
        lambda **_kwargs: (credential, [{"valid": True}]),
    )
    monkeypatch.setattr(
        module,
        "select_personal_credential",
        lambda **_kwargs: (credential, [{"valid": True}]),
    )
    gateway_calls: list[str] = []
    report = {
        "personal_runtime_proved": False,
        "organization_gateway_mutation_started": False,
        "complete": False,
    }

    with pytest.raises(module.RuntimeProofError):
        module.run_recovery(
            report,
            environment={},
            api_factory=lambda **_kwargs: object(),
            upstream_gate=lambda: {"recovery_admitted": True},
            source_resolver=lambda: (
                "e" * 40,
                {
                    "revision": "e" * 40,
                    "python_contract_suite": "success",
                    "default_branch_tip_rechecked_by_deployer": True,
                },
            ),
            runtime_deployer=lambda *_args: (_ for _ in ()).throw(
                module.RuntimeProofError("runtime failed")
            ),
            gateway_publisher=lambda _api, slug, _meta, _runtime: gateway_calls.append(
                slug
            ),
        )
    assert gateway_calls == []
    assert report["personal_runtime_proved"] is False
    assert report["organization_gateway_mutation_started"] is False


def test_static_surface_is_mobile_accessible_and_truth_bound() -> None:
    build = {
        "runtime_source_revision": "f" * 40,
        "runtime_version": "2.2.0",
        "provider_constraint": module.PROVIDER_CONSTRAINT,
        "effectors_enabled": False,
        "human_approval_required": True,
    }
    page = module.static_page(
        "Terra",
        "Parcel intelligence",
        "https://owner-runtime.hf.space/experience/terra",
        build,
    )
    for fragment in (
        'data-szl-domain-experience-v4="true"',
        'name="viewport"',
        "viewport-fit=cover",
        "min-height:48px",
        "prefers-reduced-motion:reduce",
        "forced-colors:active",
        "Human authority required",
        "location.replace",
        module.PROVIDER_CONSTRAINT,
    ):
        assert fragment in page
    card = module.static_card("Terra", "Parcel intelligence")
    assert "sdk: static" in card
    assert "app_file: index.html" in card
    assert "docker" not in card.casefold()


def test_workflow_is_post_failure_only_and_has_one_writer_lock() -> None:
    workflow = (
        ROOT / ".github" / "workflows" / "hf-free-tier-recovery.yml"
    ).read_text(encoding="utf-8")
    assert "workflow_run:" in workflow
    assert '"Sync and Relock Canonical Hugging Face Space"' in workflow
    assert "github.event.workflow_run.conclusion == 'failure'" in workflow
    assert "github.event.workflow_run.head_sha" in workflow
    assert "group: sync-relock-canonical-a11oy" in workflow
    assert "workflow_dispatch" not in workflow
    assert "HF_ORG_TOKEN1" in workflow
    assert "HF_PERSONAL_TOKEN" in workflow
    assert "gh run download" in workflow
